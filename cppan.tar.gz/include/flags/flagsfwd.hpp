#ifndef ENUM_CLASS_FLAGSFWD_HPP
#define ENUM_CLASS_FLAGSFWD_HPP


namespace flags { template <class E> class flags; }


#endif // ENUM_CLASS_FLAGSFWD_HPP
